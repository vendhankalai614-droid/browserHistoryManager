import { useState } from "react";
import { Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import type { HistoryEntry } from "@shared/schema";

export function ExportDialog() {
  const [open, setOpen] = useState(false);
  const [format, setFormat] = useState<"csv" | "json">("csv");
  const { toast } = useToast();

  const { data: entries = [] } = useQuery<HistoryEntry[]>({
    queryKey: ["/api/history"],
  });

  const handleExport = () => {
    if (entries.length === 0) {
      toast({
        title: "No Data",
        description: "There's no history to export",
        variant: "destructive",
      });
      return;
    }

    let content: string;
    let mimeType: string;
    let filename: string;

    if (format === "csv") {
      const headers = ["URL", "Title", "Visited At", "Visit Count"];
      const rows = entries.map((entry) => [
        entry.url,
        entry.title || "",
        new Date(entry.visitedAt).toISOString(),
        entry.visitCount.toString(),
      ]);
      content = [headers, ...rows].map((row) => row.join(",")).join("\n");
      mimeType = "text/csv";
      filename = `browser-history-${Date.now()}.csv`;
    } else {
      content = JSON.stringify(entries, null, 2);
      mimeType = "application/json";
      filename = `browser-history-${Date.now()}.json`;
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Success",
      description: `Exported ${entries.length} entries as ${format.toUpperCase()}`,
    });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" data-testid="button-export">
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </DialogTrigger>
      <DialogContent data-testid="dialog-export">
        <DialogHeader>
          <DialogTitle>Export History</DialogTitle>
          <DialogDescription>
            Choose a format to export your browsing history
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <RadioGroup value={format} onValueChange={(v) => setFormat(v as "csv" | "json")}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="csv" id="csv" data-testid="radio-csv" />
              <Label htmlFor="csv" className="cursor-pointer">
                CSV - Comma-separated values (for spreadsheets)
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="json" id="json" data-testid="radio-json" />
              <Label htmlFor="json" className="cursor-pointer">
                JSON - JavaScript Object Notation (for developers)
              </Label>
            </div>
          </RadioGroup>
          <p className="text-sm text-muted-foreground">
            {entries.length} {entries.length === 1 ? "entry" : "entries"} will be exported
          </p>
        </div>
        <div className="flex justify-end gap-2">
          <Button
            variant="outline"
            onClick={() => setOpen(false)}
            data-testid="button-cancel-export"
          >
            Cancel
          </Button>
          <Button onClick={handleExport} data-testid="button-download">
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
