import { Badge } from "@/components/ui/badge";
import type { Category } from "@shared/schema";

interface CategoryBadgeProps {
  category: Category;
  onClick?: () => void;
  className?: string;
}

const colorMap: Record<string, string> = {
  blue: "bg-blue-500 text-white border-blue-600",
  green: "bg-green-500 text-white border-green-600",
  purple: "bg-purple-500 text-white border-purple-600",
  orange: "bg-orange-500 text-white border-orange-600",
  pink: "bg-pink-500 text-white border-pink-600",
  yellow: "bg-yellow-500 text-black border-yellow-600",
  red: "bg-red-500 text-white border-red-600",
  teal: "bg-teal-500 text-white border-teal-600",
};

export function CategoryBadge({ category, onClick, className }: CategoryBadgeProps) {
  const colorClass = colorMap[category.color] || "bg-gray-500 text-white";

  return (
    <Badge
      variant="secondary"
      className={`${colorClass} cursor-pointer text-xs ${className || ""}`}
      onClick={onClick}
      data-testid={`badge-category-${category.id}`}
    >
      {category.name}
    </Badge>
  );
}
