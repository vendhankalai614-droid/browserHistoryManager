import {
  History,
  BarChart3,
  Settings,
  Home,
  Calendar,
  Tag,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import type { Category } from "@shared/schema";
import { CategoryBadge } from "./category-badge";
import { Card } from "@/components/ui/card";

export function AppSidebar() {
  const [location, setLocation] = useLocation();

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: stats } = useQuery<{
    totalEntries: number;
    todayEntries: number;
    thisWeekEntries: number;
  }>({
    queryKey: ["/api/history/stats"],
  });

  const menuItems = [
    { title: "History", url: "/", icon: History, testId: "link-history" },
    { title: "Statistics", url: "/statistics", icon: BarChart3, testId: "link-statistics" },
    { title: "Categories", url: "/categories", icon: Tag, testId: "link-categories" },
  ];

  return (
    <Sidebar data-testid="sidebar-main">
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-lg font-semibold">
            Browser History
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    data-testid={item.testId}
                  >
                    <Link href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {stats && (
          <SidebarGroup>
            <SidebarGroupLabel>Quick Stats</SidebarGroupLabel>
            <SidebarGroupContent>
              <Card className="p-4 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Total</span>
                  <span className="text-sm font-semibold" data-testid="text-total-entries">
                    {stats.totalEntries}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Today</span>
                  <span className="text-sm font-semibold" data-testid="text-today-entries">
                    {stats.todayEntries}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">This Week</span>
                  <span className="text-sm font-semibold" data-testid="text-week-entries">
                    {stats.thisWeekEntries}
                  </span>
                </div>
              </Card>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {categories.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel>Categories</SidebarGroupLabel>
            <SidebarGroupContent>
              <div className="flex flex-wrap gap-2 px-2">
                {categories.map((category) => (
                  <CategoryBadge
                    key={category.id}
                    category={category}
                    onClick={() => setLocation(`/?category=${category.id}`)}
                  />
                ))}
              </div>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>
    </Sidebar>
  );
}
