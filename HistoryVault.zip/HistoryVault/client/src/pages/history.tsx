import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { ExternalLink, Trash2, Edit } from "lucide-react";
import type { HistoryEntry, Category } from "@shared/schema";
import { SearchBar } from "@/components/search-bar";
import { ExportDialog } from "@/components/export-dialog";
import { ClearHistoryDialog } from "@/components/clear-history-dialog";
import { CategoryBadge } from "@/components/category-badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";

export default function History() {
  const [location] = useLocation();
  const urlParams = new URLSearchParams(location.split("?")[1]);
  const categoryParam = urlParams.get("category");

  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const { data: entries = [], isLoading } = useQuery<HistoryEntry[]>({
    queryKey: ["/api/history"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/history/${id}`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/history"] });
      queryClient.invalidateQueries({ queryKey: ["/api/history/stats"] });
      toast({
        title: "Deleted",
        description: "History entry deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete entry",
        variant: "destructive",
      });
    },
  });

  const updateCategoryMutation = useMutation({
    mutationFn: ({ id, categoryId }: { id: string; categoryId: string | null }) =>
      apiRequest("PATCH", `/api/history/${id}`, { categoryId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/history"] });
      toast({
        title: "Updated",
        description: "Category updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update category",
        variant: "destructive",
      });
    },
  });

  const filteredEntries = useMemo(() => {
    return entries.filter((entry) => {
      const matchesSearch =
        searchQuery === "" ||
        entry.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
        entry.title?.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory =
        !categoryParam || entry.categoryId === categoryParam;

      return matchesSearch && matchesCategory;
    });
  }, [entries, searchQuery, categoryParam]);

  const getCategoryById = (id: string | null) => {
    return categories.find((c) => c.id === id);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">Loading history...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="border-b p-4 space-y-4">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <h1 className="text-2xl font-semibold" data-testid="text-page-title">
            Browsing History
          </h1>
          <div className="flex items-center gap-2">
            <ExportDialog />
            <ClearHistoryDialog />
          </div>
        </div>
        <SearchBar
          value={searchQuery}
          onChange={setSearchQuery}
          placeholder="Search by URL or title..."
        />
      </div>

      <div className="flex-1 overflow-auto">
        {filteredEntries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center">
            <p className="text-lg font-medium mb-2" data-testid="text-empty-state">
              {searchQuery || categoryParam
                ? "No matching entries found"
                : "No history entries yet"}
            </p>
            <p className="text-sm text-muted-foreground">
              {searchQuery || categoryParam
                ? "Try adjusting your search or filters"
                : "Click the + button to add your first entry"}
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader className="sticky top-0 bg-background z-10">
              <TableRow>
                <TableHead className="w-[40%]">URL</TableHead>
                <TableHead className="w-[20%]">Title</TableHead>
                <TableHead className="w-[15%]">Visited</TableHead>
                <TableHead className="w-[10%]">Visits</TableHead>
                <TableHead className="w-[10%]">Category</TableHead>
                <TableHead className="w-[5%]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEntries.map((entry) => {
                const category = getCategoryById(entry.categoryId);
                return (
                  <TableRow
                    key={entry.id}
                    className="hover-elevate"
                    data-testid={`row-entry-${entry.id}`}
                  >
                    <TableCell className="font-mono text-xs">
                      <a
                        href={entry.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline flex items-center gap-1"
                        data-testid={`link-url-${entry.id}`}
                      >
                        <span className="truncate max-w-md">{entry.url}</span>
                        <ExternalLink className="h-3 w-3 flex-shrink-0" />
                      </a>
                    </TableCell>
                    <TableCell className="text-sm">
                      {entry.title || (
                        <span className="text-muted-foreground italic">No title</span>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {format(new Date(entry.visitedAt), "MMM d, yyyy HH:mm")}
                    </TableCell>
                    <TableCell className="text-sm">{entry.visitCount}</TableCell>
                    <TableCell>
                      <Select
                        value={entry.categoryId || "none"}
                        onValueChange={(value) =>
                          updateCategoryMutation.mutate({
                            id: entry.id,
                            categoryId: value === "none" ? null : value,
                          })
                        }
                      >
                        <SelectTrigger
                          className="h-7 w-full"
                          data-testid={`select-category-${entry.id}`}
                        >
                          <SelectValue>
                            {category ? (
                              <CategoryBadge category={category} />
                            ) : (
                              <span className="text-xs text-muted-foreground">None</span>
                            )}
                          </SelectValue>
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">
                            <span className="text-muted-foreground">None</span>
                          </SelectItem>
                          {categories.map((cat) => (
                            <SelectItem key={cat.id} value={cat.id}>
                              {cat.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => deleteMutation.mutate(entry.id)}
                        data-testid={`button-delete-${entry.id}`}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  );
}
