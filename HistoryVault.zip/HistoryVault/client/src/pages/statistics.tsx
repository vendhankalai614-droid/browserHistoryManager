import { useQuery } from "@tanstack/react-query";
import { BarChart3, Calendar, Globe, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { HistoryEntry, Category } from "@shared/schema";
import { CategoryBadge } from "@/components/category-badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

export default function Statistics() {
  const { data: entries = [], isLoading } = useQuery<HistoryEntry[]>({
    queryKey: ["/api/history"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: stats } = useQuery<{
    totalEntries: number;
    todayEntries: number;
    thisWeekEntries: number;
  }>({
    queryKey: ["/api/history/stats"],
  });

  const topSites = [...entries]
    .sort((a, b) => b.visitCount - a.visitCount)
    .slice(0, 10)
    .map((entry) => ({
      name: new URL(entry.url).hostname,
      visits: entry.visitCount,
    }));

  const categoryStats = categories.map((category) => {
    const count = entries.filter((e) => e.categoryId === category.id).length;
    return {
      name: category.name,
      value: count,
      color: getCategoryColor(category.color),
    };
  }).filter(stat => stat.value > 0);

  const uncategorized = entries.filter((e) => !e.categoryId).length;
  if (uncategorized > 0) {
    categoryStats.push({
      name: "Uncategorized",
      value: uncategorized,
      color: "#9ca3af",
    });
  }

  const dailyActivity = getDailyActivity(entries);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">Loading statistics...</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 overflow-auto h-full">
      <h1 className="text-2xl font-semibold" data-testid="text-page-title">
        Statistics Dashboard
      </h1>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Entries</CardTitle>
            <Globe className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-stats">
              {stats?.totalEntries || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All time browsing history
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-today-stats">
              {stats?.todayEntries || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Entries added today
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Week</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-week-stats">
              {stats?.thisWeekEntries || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Entries this week
            </p>
          </CardContent>
        </Card>
      </div>

      {topSites.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Top 10 Most Visited Sites
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topSites}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="name"
                  className="text-xs"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <YAxis
                  className="text-xs"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="visits" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        {categoryStats.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Category Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={categoryStats}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) =>
                      `${name} (${(percent * 100).toFixed(0)}%)`
                    }
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {dailyActivity.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Daily Activity (Last 7 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={dailyActivity}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="day"
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <YAxis
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar dataKey="entries" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

function getCategoryColor(colorName: string): string {
  const colorMap: Record<string, string> = {
    blue: "#3b82f6",
    green: "#10b981",
    purple: "#a855f7",
    orange: "#f97316",
    pink: "#ec4899",
    yellow: "#eab308",
    red: "#ef4444",
    teal: "#14b8a6",
  };
  return colorMap[colorName] || "#6b7280";
}

function getDailyActivity(entries: HistoryEntry[]) {
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date;
  });

  return last7Days.map((date) => {
    const dayStart = new Date(date);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(date);
    dayEnd.setHours(23, 59, 59, 999);

    const count = entries.filter((entry) => {
      const entryDate = new Date(entry.visitedAt);
      return entryDate >= dayStart && entryDate <= dayEnd;
    }).length;

    return {
      day: date.toLocaleDateString("en-US", { weekday: "short" }),
      entries: count,
    };
  });
}
