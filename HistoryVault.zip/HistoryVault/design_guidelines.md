# Design Guidelines: Browser History Manager Web Application

## Design Approach: Productivity-Focused Design System

**Selected Approach:** Design System (Productivity-Optimized)  
**Primary Inspiration:** Linear + Material Design  
**Justification:** This is a data-intensive productivity tool requiring efficient information display, robust search/filter capabilities, and clear data visualization. Linear's clean aesthetic combined with Material Design's comprehensive component system provides the optimal foundation.

**Core Design Principles:**
- Clarity over decoration: Every element serves a functional purpose
- Information density: Maximum utility without overwhelming users
- Immediate action: Critical features accessible within 1-2 clicks
- Data-first: Content takes priority over chrome

---

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary):**
- Background Base: 220 15% 8% (deep slate)
- Background Elevated: 220 15% 12% (cards/panels)
- Background Subtle: 220 15% 15% (hover states)
- Primary Accent: 217 91% 60% (bright blue for actions)
- Text Primary: 0 0% 95%
- Text Secondary: 220 9% 65%
- Border: 220 13% 20%
- Success: 142 71% 45%
- Warning: 38 92% 50%
- Danger: 0 84% 60%

**Light Mode:**
- Background Base: 0 0% 100%
- Background Elevated: 220 15% 98%
- Primary Accent: 217 91% 50%
- Text Primary: 220 15% 15%
- Border: 220 13% 91%

### B. Typography

**Font Families:**
- Primary: 'Inter' (interface, body text)
- Monospace: 'JetBrains Mono' (URLs, timestamps, code)

**Hierarchy:**
- Page Titles: text-2xl font-semibold (24px)
- Section Headers: text-lg font-medium (18px)
- Body Text: text-sm (14px)
- Metadata/Timestamps: text-xs (12px)
- URLs: text-sm font-mono

### C. Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8
- Component padding: p-4 to p-6
- Section spacing: space-y-6 to space-y-8
- Card gaps: gap-4
- Page margins: mx-4 to mx-8

**Grid Structure:**
- Sidebar navigation: w-64 (fixed)
- Main content: flex-1 max-w-6xl mx-auto
- Dashboard widgets: grid-cols-1 md:grid-cols-2 lg:grid-cols-3

### D. Component Library

**Navigation:**
- Sidebar (fixed left): Category list, quick actions, statistics summary
- Top bar: Search, filter controls, user menu, export button
- Breadcrumbs: Context navigation for filtered views

**Data Display:**
- History List: Table with columns (Timestamp | URL | Category | Actions)
- Compact cards for mobile view
- Infinite scroll or pagination (50 items per page)
- Row actions: Edit category, delete (icon buttons on hover)

**Forms & Controls:**
- Add history modal: Floating dialog with URL input, category dropdown, timestamp
- Search bar: Prominent, with real-time filtering
- Filter chips: Category tags, date range selectors (removable)
- Category manager: Inline editing, color picker for category badges

**Statistics Dashboard:**
- Metric cards: Visit count, top sites, category distribution (grid layout)
- Simple bar charts: Top 10 sites (use Chart.js or similar)
- Time-based graphs: Daily/weekly activity patterns
- Category pie chart: Visual breakdown

**Overlays:**
- Modal dialogs: Confirmation (delete, clear history), Add entry
- Dropdown menus: Category selection, export format options
- Toast notifications: Success/error feedback (top-right, auto-dismiss)

### E. Visual Patterns

**Cards & Containers:**
- Rounded corners: rounded-lg (8px)
- Subtle shadows: shadow-sm on elevated surfaces
- Border treatment: border border-border for definition

**Interactive States:**
- Hover: Subtle background shift (bg-elevated to bg-subtle)
- Active/Selected: Primary accent border-l-4 indicator
- Focus: Ring offset for keyboard navigation

**Data Table Enhancements:**
- Zebra striping: Alternate row colors for readability
- Fixed headers: Sticky positioning when scrolling
- Sort indicators: Arrow icons in column headers
- Empty state: Helpful illustration with "Add your first entry" CTA

**Category System:**
- Color-coded badges: 8 preset colors (blue, green, purple, orange, etc.)
- Icon support: Optional category icons
- Quick filter: Click badge to filter by category

**Export Interface:**
- Format selector: Radio buttons (CSV, JSON)
- Date range: Optional filtering before export
- Download button: Prominent with download icon

---

## No Hero Section / Marketing Elements

This is a **pure application interface** - launch directly into the functional workspace:
- Left sidebar navigation immediately visible
- Main area shows history list or dashboard
- Top utility bar with search and actions
- No landing page; user goes straight to their data

---

## Accessibility & Performance

- Dark mode toggle in user menu (persisted preference)
- Keyboard shortcuts: Cmd+K for search, Cmd+N for new entry
- ARIA labels on all interactive elements
- Lazy load history items for performance
- Optimistic UI updates for instant feedback
- Debounced search (300ms) to reduce re-renders

---

## Key UI Flows

1. **Add Entry:** Floating action button (bottom-right) → Modal → Success toast
2. **Search:** Top bar input → Real-time filter → Clear button appears
3. **Categorize:** Inline dropdown in table row → Update → Visual feedback
4. **Export:** Top bar button → Format selector modal → Download trigger
5. **Statistics:** Sidebar link → Full dashboard view with charts and metrics