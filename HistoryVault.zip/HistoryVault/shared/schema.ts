import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const categories = pgTable("categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  color: text("color").notNull(),
});

export const historyEntries = pgTable("history_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  url: text("url").notNull(),
  title: text("title"),
  categoryId: varchar("category_id").references(() => categories.id),
  visitedAt: timestamp("visited_at", { withTimezone: true }).notNull().defaultNow(),
  visitCount: integer("visit_count").notNull().default(1),
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
});

export const insertHistoryEntrySchema = createInsertSchema(historyEntries).omit({
  id: true,
  visitedAt: true,
  visitCount: true,
}).extend({
  url: z.string().url("Please enter a valid URL"),
  title: z.string().optional(),
  categoryId: z.string().optional(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type HistoryEntry = typeof historyEntries.$inferSelect;
export type InsertHistoryEntry = z.infer<typeof insertHistoryEntrySchema>;

export const CATEGORY_COLORS = [
  { value: "blue", label: "Blue", class: "bg-blue-500" },
  { value: "green", label: "Green", class: "bg-green-500" },
  { value: "purple", label: "Purple", class: "bg-purple-500" },
  { value: "orange", label: "Orange", class: "bg-orange-500" },
  { value: "pink", label: "Pink", class: "bg-pink-500" },
  { value: "yellow", label: "Yellow", class: "bg-yellow-500" },
  { value: "red", label: "Red", class: "bg-red-500" },
  { value: "teal", label: "Teal", class: "bg-teal-500" },
] as const;
