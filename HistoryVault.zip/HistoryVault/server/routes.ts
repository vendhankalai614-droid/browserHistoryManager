import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertHistoryEntrySchema, insertCategorySchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { z } from "zod";

const updateHistoryEntrySchema = z.object({
  url: z.string().url().optional(),
  title: z.string().optional(),
  categoryId: z.string().optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/history", async (req, res) => {
    try {
      const { search, category } = req.query;
      let entries = await storage.getHistoryEntries();

      if (search && typeof search === "string") {
        const searchLower = search.toLowerCase();
        entries = entries.filter(
          (e) =>
            e.url.toLowerCase().includes(searchLower) ||
            e.title?.toLowerCase().includes(searchLower)
        );
      }

      if (category && typeof category === "string") {
        entries = entries.filter((e) => e.categoryId === category);
      }

      res.json(entries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch history" });
    }
  });

  app.get("/api/history/export", async (req, res) => {
    try {
      const { format = "csv" } = req.query;
      const entries = await storage.getHistoryEntries();

      if (format === "csv") {
        const headers = ["URL", "Title", "Visited At", "Visit Count", "Category ID"];
        const rows = entries.map((entry) => [
          entry.url,
          entry.title || "",
          new Date(entry.visitedAt).toISOString(),
          entry.visitCount.toString(),
          entry.categoryId || "",
        ]);
        const csv = [headers, ...rows].map((row) => row.join(",")).join("\n");

        res.setHeader("Content-Type", "text/csv");
        res.setHeader(
          "Content-Disposition",
          `attachment; filename=browser-history-${Date.now()}.csv`
        );
        res.send(csv);
      } else if (format === "json") {
        res.setHeader("Content-Type", "application/json");
        res.setHeader(
          "Content-Disposition",
          `attachment; filename=browser-history-${Date.now()}.json`
        );
        res.json(entries);
      } else {
        res.status(400).json({ error: "Invalid format. Use 'csv' or 'json'" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to export history" });
    }
  });

  app.get("/api/history/stats", async (_req, res) => {
    try {
      const entries = await storage.getHistoryEntries();
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekStart = new Date(now);
      weekStart.setDate(now.getDate() - 7);

      const stats = {
        totalEntries: entries.length,
        todayEntries: entries.filter(
          (e) => new Date(e.visitedAt) >= todayStart
        ).length,
        thisWeekEntries: entries.filter(
          (e) => new Date(e.visitedAt) >= weekStart
        ).length,
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch statistics" });
    }
  });

  app.post("/api/history", async (req, res) => {
    try {
      const result = insertHistoryEntrySchema.safeParse(req.body);
      if (!result.success) {
        const error = fromZodError(result.error);
        return res.status(400).json({ error: error.message });
      }

      const entry = await storage.createHistoryEntry(result.data);
      res.status(201).json(entry);
    } catch (error) {
      res.status(500).json({ error: "Failed to create history entry" });
    }
  });

  app.patch("/api/history/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const body = { ...req.body };
      if (body.categoryId === null) {
        body.categoryId = undefined;
      }
      
      const result = updateHistoryEntrySchema.safeParse(body);
      if (!result.success) {
        const error = fromZodError(result.error);
        return res.status(400).json({ error: error.message });
      }

      const updated = await storage.updateHistoryEntry(id, result.data);

      if (!updated) {
        return res.status(404).json({ error: "History entry not found" });
      }

      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update history entry" });
    }
  });

  app.delete("/api/history/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteHistoryEntry(id);

      if (!deleted) {
        return res.status(404).json({ error: "History entry not found" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete history entry" });
    }
  });

  app.delete("/api/history/clear", async (_req, res) => {
    try {
      await storage.clearHistory();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear history" });
    }
  });

  app.get("/api/categories", async (_req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    try {
      const result = insertCategorySchema.safeParse(req.body);
      if (!result.success) {
        const error = fromZodError(result.error);
        return res.status(400).json({ error: error.message });
      }

      const category = await storage.createCategory(result.data);
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to create category" });
    }
  });

  app.delete("/api/categories/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteCategory(id);

      if (!deleted) {
        return res.status(404).json({ error: "Category not found" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete category" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
