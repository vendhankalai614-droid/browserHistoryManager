import {
  type HistoryEntry,
  type InsertHistoryEntry,
  type Category,
  type InsertCategory,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getHistoryEntries(): Promise<HistoryEntry[]>;
  getHistoryEntry(id: string): Promise<HistoryEntry | undefined>;
  createHistoryEntry(entry: InsertHistoryEntry): Promise<HistoryEntry>;
  updateHistoryEntry(
    id: string,
    data: Partial<InsertHistoryEntry>
  ): Promise<HistoryEntry | undefined>;
  deleteHistoryEntry(id: string): Promise<boolean>;
  clearHistory(): Promise<void>;

  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  deleteCategory(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private historyEntries: Map<string, HistoryEntry>;
  private categories: Map<string, Category>;

  constructor() {
    this.historyEntries = new Map();
    this.categories = new Map();
    this.seedDefaultCategories();
  }

  private seedDefaultCategories() {
    const defaultCategories: InsertCategory[] = [
      { name: "Work", color: "blue" },
      { name: "Personal", color: "green" },
      { name: "Research", color: "purple" },
      { name: "Entertainment", color: "orange" },
    ];

    defaultCategories.forEach((cat) => {
      const id = randomUUID();
      this.categories.set(id, { ...cat, id });
    });
  }

  async getHistoryEntries(): Promise<HistoryEntry[]> {
    return Array.from(this.historyEntries.values()).sort(
      (a, b) => new Date(b.visitedAt).getTime() - new Date(a.visitedAt).getTime()
    );
  }

  async getHistoryEntry(id: string): Promise<HistoryEntry | undefined> {
    return this.historyEntries.get(id);
  }

  async createHistoryEntry(
    insertEntry: InsertHistoryEntry
  ): Promise<HistoryEntry> {
    const id = randomUUID();
    const entry: HistoryEntry = {
      ...insertEntry,
      id,
      visitedAt: new Date(),
      visitCount: 1,
      title: insertEntry.title || null,
      categoryId: insertEntry.categoryId || null,
    };
    this.historyEntries.set(id, entry);
    return entry;
  }

  async updateHistoryEntry(
    id: string,
    data: Partial<InsertHistoryEntry>
  ): Promise<HistoryEntry | undefined> {
    const entry = this.historyEntries.get(id);
    if (!entry) return undefined;

    const updated: HistoryEntry = {
      ...entry,
      ...data,
      categoryId: data.categoryId !== undefined ? data.categoryId : entry.categoryId,
    };
    this.historyEntries.set(id, updated);
    return updated;
  }

  async deleteHistoryEntry(id: string): Promise<boolean> {
    return this.historyEntries.delete(id);
  }

  async clearHistory(): Promise<void> {
    this.historyEntries.clear();
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: string): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  async deleteCategory(id: string): Promise<boolean> {
    const deleted = this.categories.delete(id);
    if (deleted) {
      const entries = await this.getHistoryEntries();
      for (const entry of entries) {
        if (entry.categoryId === id) {
          await this.updateHistoryEntry(entry.id, { categoryId: undefined });
        }
      }
    }
    return deleted;
  }
}

export const storage = new MemStorage();
